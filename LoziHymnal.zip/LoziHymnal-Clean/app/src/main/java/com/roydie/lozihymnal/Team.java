package com.roydie.lozihymnal;

/**
 * Created by rsimasiku on 11/12/2015.
 */

import java.util.ArrayList;

public class Team {
    //PROPARTIES OF A SIGNLE TEAM
    public String Name;
    public String Image;
    public  ArrayList<String> players=new ArrayList<String>();

    public Team(String Name)

    {
        this.Name=Name;
    }
    @Override
    public  String toString(){
        //TODO Auto-generated method stub
        return Name;
    }

}
