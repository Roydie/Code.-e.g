package com.roydie.lozihymnal;

/**
 * Created by rsimasiku on 11/12/2015.
 */
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends BaseExpandableListAdapter{

    private Context c;
    private ArrayList<Team> team;
    private LayoutInflater inflater;

    public CustomAdapter (Context c,ArrayList<Team> team){
        this.c=c;
        this.team=team;
        inflater=(LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }



    //GET A SINGLE PLAYER
    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return team.get(groupPosition).players.get(childPosition);
    }


    //GET A PLAYER ID
    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return 0;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }



    //GET PLAYER ROW
    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        //ONLY INFLATER XML ROW LAYOUT IF ITS NOT PRESENT, OTHERWISE REUSE IT
        if(convertView==null)
        {
            convertView=inflater.inflate(R.layout.player,null);
        }

        //GET CHILD/PLAYER NAME
        String child=(String) getChild(groupPosition, childPosition);

        //SET CHILD NAME
        TextView nameTv=(TextView) convertView.findViewById(R.id.textView1);
        ImageView img= (ImageView) convertView.findViewById(R.id.imageView1);

        nameTv.setText(child);

        //GET TEAM NAME
        String teamName= getGroup(groupPosition).toString();

        //ASSIGN IMAGES TO PLAYERS ACCORDING TO THEIR NAMES AND TEAMS
        if(teamName==" 1-20")
        {
            if(child=="1.Lila Pala"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="2.Mulena U Fa Munyako"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="3.Muta Lu Ta Bonana"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="4.Wa Ta"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="5.Kwa Munzi Ki Kwahule Nji?"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="6.Balumeli A Mu Tone"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="7.Ha A Ka Taha"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="8.Muta Mabizo A Bizwa"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="9.Mu Lize Pala"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="10.Lu Ta Kopana Kwa Nuka"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="11.Ni Ta Ku Latelala"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="12.Ku Na Ni Siliba"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="13.Mulena Jesu, Nilakaza Ku Fola"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="14.Utwa Mali A Wa"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="15.Jesu Wa Ni Lata"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="16.Mautunyana, Mamela"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="17.Lu Tabiswa Ki ‘Lato Le Li Wabelisa"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="18.Bahali Ba Jesu, A Mu Ye Kwa Ndwa!"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="19.Moyo Wa Ka, Tokomeka"){
                img.setImageResource(R.drawable.music);
            }
            else if(child=="20.Zuha, Moyo Wa Ka!"){
                img.setImageResource(R.drawable.music);
            }
            else if(teamName==" 21-40")
            {
                if (child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }

            }
            else if (teamName==" 41-60"){
                if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
                else if(child=="Song title"){
                    img.setImageResource(R.drawable.music);
                }
            }


        }

        return convertView;
    }

    @Override
    //GET NUMBER OF PLAYERS
    public int getChildrenCount(int groupPositionw) {
        return team.get(groupPositionw).players.size();
    }
    //GET TEAM
    @Override
    public Object getGroup(int groupPosition) {
        return team.get(groupPosition);
    }
    //GET NUMBER OF TEAMS
    @Override
    public int getGroupCount() {
        return team.size();
    }
    //GET TEAM ID
    @Override
    public long getGroupId(int arg0) {
        return 0;
    }
    //GET TEAM ROW
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        if(convertView==null){
            convertView=inflater.inflate(R.layout.teams,null);
        }

        //GET GROUP / TEAM ITEM
        Team t=(Team)getGroup(groupPosition);

        //SET GROUP NAME
        TextView nameTv=(TextView) convertView.findViewById(R.id.textView1);
        ImageView img=(ImageView) convertView.findViewById(R.id.imageView1);

        String name=t.Name;
        nameTv.setText(name);

        //ASSIGN TEAM IMAGES ACCORDING TO TEAM NAME
        if(name==" 1-20"){
            img.setImageResource(R.drawable.musik);
        }else if(name==" 21-40"){
            img.setImageResource(R.drawable.musik);
        }else if(name==" 41-60"){
            img.setImageResource(R.drawable.musik);
        }

        //SET TEAM BACKGROUND COLOR
        convertView.setBackgroundColor(Color.LTGRAY);

        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}

