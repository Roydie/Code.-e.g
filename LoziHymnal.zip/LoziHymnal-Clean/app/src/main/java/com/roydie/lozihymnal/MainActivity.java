package com.roydie.lozihymnal;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    protected List<String> data;
    public static final String SONG_DESC = "songDesc";
    public static final int DETAIL_REQUEST_CODE = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        data = DataProvider.getData();

        //THE EXPANDABLE
        ExpandableListView elv =(ExpandableListView)findViewById(R.id.expandableListView);

        final ArrayList<Team> team=getData();

        //CREATE AND BIND TO ADAPTER
        CustomAdapter adapter=new CustomAdapter(this,team);
        elv.setAdapter(adapter);

        //SET ONCLICK LISTENER
        elv.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                String song = data.get(childPosition);
                displayDetail(song);
                return false;
            }
        });

    }
    private void displayDetail(String song) {

        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(SONG_DESC, song);
        startActivityForResult(intent, DETAIL_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == DETAIL_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                String msg = data.getStringExtra("resultMessage");
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
            }
        }

    }
    //ADD AND GET DATA
    private ArrayList<Team> getData(){

        Team t1= new Team(" 1-20");
        t1.players.add("1.Lila Pala");
        t1.players.add("2.Mulena U Fa Munyako");
        t1.players.add("3.Muta Lu Ta Bonana");
        t1.players.add("4.Wa Ta");
        t1.players.add("5.Kwa Munzi Ki Kwahule Nji?");
        t1.players.add("6.Balumeli A Mu Tone");
        t1.players.add("7.Ha A Ka Taha");
        t1.players.add("8.Muta Mabizo A Bizwa");
        t1.players.add("9.Mu Lize Pala");
        t1.players.add("10.Lu Ta Kopana Kwa Nuka");
        t1.players.add("11.Ni Ta Ku Latelala");
        t1.players.add("12.Ku Na Ni Siliba");
        t1.players.add("13.Mulena Jesu, Nilakaza Ku Fola");
        t1.players.add("14.Utwa Mali A Wa");
        t1.players.add("15.Jesu Wa Ni Lata");
        t1.players.add("16.Mautunyana, Mamela");
        t1.players.add("17.Lu Tabiswa Ki ‘Lato Le Li Wabelisa");
        t1.players.add("18.Bahali Ba Jesu, A Mu Ye Kwa Ndwa!");
        t1.players.add("19.Moyo Wa Ka, Tokomeka");
        t1.players.add("20.Zuha, Moyo Wa Ka!");

        Team t2 = new Team(" 21-40");
        t2.players.add("21. Na ta kwa sifapano");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");
        t2.players.add("Song title");

        Team t3= new Team(" 41-60");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        t3.players.add("Song title");
        

        ArrayList<Team> allTeams=new ArrayList<Team>();
        allTeams.add(t1);
        allTeams.add(t2);
        allTeams.add(t3);

        return allTeams;

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
