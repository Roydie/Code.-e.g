package com.roydie.lozihymnal;

import java.util.ArrayList;
import java.util.List;

class DataProvider {

    private static List<String> data = new ArrayList<>();

    public static List<String> getData() {
        return data;
    }

    static {

        data.add("1.Muluti, u lize pala. U ilize hahulu;\n" +
                "Ya ta utwa bulumiwa, A fetuhe, a pile.\n" +
                "\n" +
                "MAKUTELO:\n" +
                "Muluti, u lize pal, U ilize hahulu;\n" +
                "Mulimu U li, U lize! Ba te ba lukuluhe\n" +
                "\n" +
                "2.I lilise fa malundu, Mwa mishitu, mabala;\n" +
                "Ba mawate huweleza, puluso ya sibili. \n" +
                "\n" +
                "3.I lilise mwa nzila, Mwa maneku a mansu;\n" +
                "I li, lika li lukile. Ndate U sa litezi,\n" +
                "\n" +
                "4.Zibisa ba ba imezwi, Ba ba bata Mulena;\n" +
                "Zibisa pizo ya Jesu, ye li, “A mu te ku ‘Na”.\n" +
                "\t ");

        data.add("1.Mulena U fa munyako, Yan a lwezi sifapano,\n" +
                "Ee, ba ba lukile cwale, Ba t’o ya ni Jesu. \n" +
                "\n" +
                "MAKUTELO:\n" +
                "Munyako, munyako, Mulena u ‘nzi fa munyako. \n" +
                "Jesu wa ta, Jesu wa ta, U yemi fa munyako. \n" +
                "\n" +
                "2.Lisupo za Hae za kuta, Ka mwaha za ezahala,\n" +
                "Lu tuha lu bona cwale, Ku taha kwa Jesu. \n" +
                "\n" +
                "3.Fa fasi lindw’a li feli, Ha ku na kozo ni tabo,\n" +
                "Konji Mulena h’a kuta, kut’o feza lifu. \n" +
                "\n" +
                "4.Hona mo mwa naha ye nca, Lu yo ‘na lu li ba banca,\n" +
                "Lu ka y’o ina lu sa shwi, kamitanimita. ");

        data.add("1.Kamuta lu ta bonana Ni Jesu ku ta ba cwañ?\n" +
                "Ki tabo ha  ni Mu bona, Jesu Ya n’a ni shwezi. \n" +
                "\n" +
                "MAKUTELO:\n" +
                "Kamuta lu ta bonana, kwahule kwahalimu\n" +
                "Lu ta bonana mwa kanya, Ni tuha ni mu bona.\n" +
                "\n" +
                "2.Ni mu bona mwa lififi, Ni siliwa ki sika;\n" +
                "Lizazi le linde la ta, Ha ku ta bonwa kanya.\n" +
                "\n" +
                "3.Ha ki tabo fapil’a Hae, Manyando a ta fela;\n" +
                "Muta ku luka ze maswe, Ze patilwe li bonwe. \n" +
                "\n" +
                "4.Ku bonana ha ki bunde! Ku bona ni ku ziba;\n" +
                "Ku bonana ni Mulena Jesu Ya ni latile. .");

        data.add("1.Ki a mande manzwi mwa zebe ya mueti,\n" +
                "Yanz’a yambaela kwahule!\n" +
                "Kapili-pili Mupulusi Wa ta, Cwale mubuso Wa ta.\n" +
                "\n" +
                "MAKUTELO:\n" +
                "Wa taha, Wa taha cwanuñu fa lifasi le;\n" +
                "Wa taha fa lifasi le;\n" +
                "Mi baeti ba ta t’o ya  kwa kanya,\n" +
                "Jesu ha A t’o lena.\n" +
                "\n" +
                "2.Mabita a kale mo ku ‘nzi baeti,\n" +
                "A ta t’o kwahululwa cwale;\n" +
                "Ee, ni ba ba lobezi mwa liwate,\n" +
                "Ba ta ‘na fa fasi fa.\n" +
                "\n" +
                "3.Luta katana mwa Edeni yo munca,\n" +
                "Luta opela lipina zende;\n" +
                "Ba tazwa  kwa mutulo ni kwa mbowela;\n" +
                "Ku t’o lapela Jesu. \n" +
                "\n" +
                "4.Aleluya, Amen! Aleluya hape!\n" +
                "Lwa ya cwale ha lu sepeha;\n" +
                "Lu libelele ni ku nyakalala,\n" +
                "Lu ta fiwa mushukwe.");

        data.add(  "1.Kwa munzi ki kwahule, nji? Na buza, muluti a li: \n" +
                        "“Busihu bu se bu fela, Se ku tuha ku sa.\n" +
                        "Tuhela ku lila hape, U akufele ku tuha.\n" +
                        "U ta fitela liseli, Musihali – tuna.”\n" +
                        "\n" +
                        "2.Ni buzize mutabani: Pina ye latwa ki yena: \n" +
                        "“Ni ta lwana ka bundume, Ndwa ‘se i ta fela.\n" +
                        "Tuhela ku lila hape, Tundamena ndwa u kome:\n" +
                        "U ta fumana mupuzo. Ha u s’o komile.”\n" +
                        "\n" +
                        "3.Ni buzize hape, lika kamukana za alaba:\n" +
                        "“Sibaka si se si fela, Munzi u fa kaufi.\n" +
                        "Tuhela ku lila hape, Liponiso ki ze ñata,\n" +
                        "Libupiwa li yemezi Kulila kwa pala.”\n" +
                        "\n" +
                        "4.Ha si kwahule kwa munzi! Mawe, kupulo ye nde-nde!\n" +
                        "Ye tabisa muzamayi, Ni ku tusa mioko:\n" +
                        "Tuhela ku lila hape, lu tuha lu y’o kopana,\n" +
                        "Manyando se a ta fela, Mwa munzi wa Ndate. ");

        data.add("1.Balumeli, a mu tone, A mu bone liponiso:\n" +
                "A mu tukise maboni, Kakuli Jesu Wa taha.\n" +
                "\n" +
                "MALUTELO:\n" +
                "Wa taha! Jesu Wa ta! Wa taha: U ta ka kanya!\n" +
                "Jesu Wa ta A t’o busa, Wa taha! Ee Wa taha.\n" +
                "\n" +
                "2.Sepiso ya Mupulusi, Musa o kile wa lekwa;\n" +
                "Likubo ze na ni mali, Li bonise tukuluho. \n" +
                "\n" +
                "3.Mibuso i nze i fela, Utwa mulumo wa taha;\n" +
                "Zibisa batu za muhau. Ha ku nze ku lila pala.\n" +
                "\n" +
                "4.Machaba a kokobela, Jesu inzi fa kaufi;\n" +
                "Lifasi ‘se li laeza,. Huweleza balumeli. \n" +
                "\n" +
                "5.Baezalibi mu tahe. Jesu h’a sa mi yemela;\n" +
                "Muhau ha u sa li teñi. Ku tuha ku fela cwale.");

        data.add("1.H’a ka taha, h’a ka taha, ku t’o puta batu;\n" +
                "Kamukana balumeli, Ba ba latiwa. \n" +
                "\n" +
                "MAKUTELO:\n" +
                "Ku swana linaleli, ku benya hahulu;\n" +
                "Mwa mushukwe wa Jesu, Ba u benyise.\n" +
                "\n" +
                "2.U ta puta, ku putela Batu mwa mubuso;\n" +
                "Kamukana ba bande-nde, Ba ba latiwa.\n" +
                "\n" +
                "3.Banana ba banyinyani, Ba ba lata Jesu;\n" +
                "Ki bona batu ba Jesu, Ba ba latiwa. ");

        data.add( "1.Muta pala i ta lila, nako ha i ta fela, \n" +
                        "La kakusasana ko ku sa feli; \n" +
                        "Ba ba pulusizwe ha ba ta kopana mwa buse, \n" +
                        "Muta mabizw’a bizwa ni ta ba teñ.\n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Muta mabizo a bizwa, muta mabizo a bizwa,\n" +
                        "Muta mabizo a bizwa, muta mabizw’a bizwa ni ta ba teñ.\n" +
                        "\n" +
                        "2.Kakusasana muta ba ta zuha balumeli,\n" +
                        "Ba abezwi kanya ya zuho ya Hae. \n" +
                        "Ba ba Ketilwe ha ba ta  kopanela mwa munzi,\n" +
                        "Muta mabizw’a bizwa ni ta ba teñ.  \n" +
                        "\n" +
                        "3.A lu sebeleze Jesu kuisa manzibuana. \n" +
                        "A lu bulele za lilato la Hae;\n" +
                        "Ha bupilo ni musebezi wa luna li fela. \n" +
                        "Muta mabizw’a bizwa ni ta ba teñ. ");

        data.add("1.Mu lize pala, Ka ku tumusa: Jesu wa taha hape!\n" +
                "Tabeñi baeti, nu ku opela: Jesu Wa taha hape!\n" +
                "\n" +
                "MAKUTELO:\n" +
                "Wa ta hape. Wa ta hape. Jesu Wa taha hape!\n" +
                "\n" +
                "2.Huwa malundu, mina mabala: Jesu wa taha hape!\n" +
                "U ta ka kanya. Ngu ye tabilwe. Jesu Wa taha hape!\n" +
                "\n" +
                "3.Mandinda mwa liwate. Mu huwe. Jesu Wa taha hape!\n" +
                "Huwa mushabati fa likamba: Jesu Wa taha hape!\n" +
                "\n" +
                "4.Lisisinyeho za lu zibisa: Jesu Wa taha hape!\n" +
                "Tukundukundu twa lu lemusa. Jesu Wa taha hape!\n" +
                "\n" +
                "5.Ba mwa licaba ba halifile. Jesu Wa taha hape!\n" +
                "Zibo buñata. Ku mata-mata. Jesu Wa taha hape!");

        data.add(
                "1.Lu ta kopana kwa nuka. Ko ku kanya ko kunde:\n" +
                        "Kwa mezi a mande luli. A buba kwa lubona?\n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Lu ta kopana kwa nuka. E, ki kwa nuka ye nde hahulu:\n" +
                        "Lukopanele kwa nuka. Ye buba kwa lubona. \n" +
                        "\n" +
                        "2.Fa likamba la nuka ye. Ki fa bubela mezi;\n" +
                        "Lu ta lapela kamita, Lizazi kamukana.\n" +
                        "\n" +
                        "3.Lu si ka fita kwa nuka. A lu lule mitiyo;\n" +
                        "Ka musa lu ta kululwa. Lu fiwa siapalo.\n" +
                        " \n" +
                        "4.Cwale lwa fita kwa nuka. Musipili wa fela;\n" +
                        "Cwanoñu ‘pilu za taba. Ka lipina za tabo.");

        data.add(
                "1.Ni ta latelela  Jesu. Kai ni kai ko ni inzi:\n" +
                        "Kai ni kai ko’ Ya ni ta ya. Eni, ni ta londota. \n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Ni ta latelela Jesu. U ni shwezi kaniti;\n" +
                        "Ni ha ba ku fulalela, Ni ta ku latelela.\n" +
                        "\n" +
                        "2.Ni ha nzila i li maswe, Ye sina bulondotwi\n" +
                        "Ni kile wa i zamaya. Ni ta ku latelela. \n" +
                        "\n" +
                        "3.Ni ka fumana manyaando, Ni ku likwa hahulu;\n" +
                        "Ni wena U n’o likilwe, Ni ta ku latelela. \n" +
                        "\n" +
                        "4.Ni ha ni li mwa manyando. Ni li ya fulalezwi;\n" +
                        "Wena U no li munyandi. Ni ta ku latelela.\n" +
                        " \n" +
                        "5.Ni ha ni ya mwa mandinda. A bata, a tungile;\n" +
                        "Wena U n’o a silile. Ni sa ku latelela.");

        data.add("1.Bona siliba sa mali, A zwile ku Jesu;\n" +
                "Lisinyi ze nwela mwa teñ’, Li tapa milatu.\n" +
                "Li tapa milatu, Li tapa milatu; \n" +
                "Lisinyi ze nwela mwa teñ’, Li tapa milatu\n" +
                "\n" +
                "2.‘Sholi la taba ku bona, Sona siliba se;\n" +
                "Ni ‘na ya swana ni Yena, Ni tapise libi.\n" +
                "Ni tapise libi, Ni tapise libi;\n" +
                "Ni ‘na ya swana ni Yena, Ni tapise libi.\n" +
                " \n" +
                "3.Mawe, Jesu, mali  a Hao, H’a na ku fokola;\n" +
                "Mane batu ba Mulimu, Ba y’o liululwa;\n" +
                "Ba y’o liululwa, Ba y’o liululwa.\n" +
                "Mane batu ba Mulimu, Ba y’o liululwa.\n" +
                " \n" +
                "4.Ka sepo ni boni mali, A zwa mwa mañiba;\n" +
                "Ni ambola za lilato, Mane muta ni shwa.\n" +
                "Mane muta ni shwa, Mane muta ni shwa. \n" +
                "Ni ambola za lilato, Mane muta ni shwa. \n" +
                "\n" +
                "5.Jesu Wa ni lukiseza. Ni ha ni li maswe;\n" +
                "Tifo ya mali a Jesu, Bupilo katima.\n" +
                "Bupilo kamita, Bupilo kamita;\n" +
                "Tifo ya mali a Jesu, Bupilo kamita.\n" +
                " \n" +
                "6.Pina i teñ’ ye munati. Ye ni ta opela;\n" +
                "Muta lilimi le la ka, li zwa mwa libita.\n" +
                "Li zwa mwa libita, Li zwa mwa libita;\n" +
                "Muta lilimi le la ka, Li zwa mwa libita.");

        data.add( "1.Jesu, ni lakaza kuli ni fole; Ni bata kuli U to ina ni ‘na;\n" +
                "Zwisa maswaniso, leleka sila, U ni tapise ni be yomusweu.\n" +
                "\n" +
                "MAKUTELO:\n" +
                "Basweu twaa, ee, busweu twaa. U ni tapise ni be yo musweu\n" +
                "\n" +
                "2.Kwa halimu ko ‘inzi, ni talime, Ni tuse ha ni ipea ku Wena;\n" +
                "Ni ipa ili ‘na, ni lika za ka, U ni tapise ni be  yo musweu\n" +
                "\n" +
                "3.Jesu na Ku kupa ka ku lapela, Ni ‘ne fa mautu a takisizwe;\n" +
                "Ka sepo ni bona mali a’ buba; U ni tapise ni be yomusweu.\n" +
                "\n" +
                "4.Jesu, na ku litela ka sibili; Cwale t’o ni bupele pilu ye nca;\n" +
                "Ba ba Ku bata ha U si ka li, Nya; U ni tapise ni be yomusweu.");

        data.add(
                "1.Utwa mali a wa! Teeleza a wa;\n" +
                        "Ki mali a Jesu, A ya ku Yena.\n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Njele, njele cwalo, A zwa kwa bana;\n" +
                        "Ki mali a Jesu, A ya ku Yena.\n" +
                        "\n" +
                        "2.Njele, njele cwalo, A zwa kwa bana;\n" +
                        "I li mpo ya Jesu, Ye zwa ku luna.\n" +
                        "\n" +
                        "3.Ni ha lu li bana, Lu fana cwalo;\n" +
                        "Muta lu hulile, Lu ta ku fanga.\n" +
                        "\n" +
                        "4.Niha lu shebile, Lu ka Mu lata;\n" +
                        "U nga mpo ya luna, Ka ku wabelwa.");

        data.add(
                "1.Wani lata, na ziba, Ku bulela Bibele;\n" +
                        "Banana ki ba Jesu, Ba fokola, Yena nyaa.\n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Ee, Wa ni lata, Ee, Wa ni lata;\n" +
                        "Ee, Wa ni lata, Ku bulela Linzwi.\n" +
                        "\n" +
                        "2.Wa ni lata, Na shwile, ku kwalula munyako;\n" +
                        "U ta tapisa libi, Kuli ni te ni kene.\n" +
                        "\n" +
                        "3.Wa ni lata hahulu, Ha ni li mwa maswabi;\n" +
                        "H’a inzi fa lubona, Jesu Wa ni talima.\n" +
                        "\n" +
                        "4.Wa ni lata, U ina Fa kaufi-kaufi ni na;\n" +
                        "Haiba ni Mu lata. Ni ta ya kwa halimu. ");

        data.add( "1.Ni tapile mazoho, mawe, a masweu, \n" +
                "Ni kalimile Jesu, Ku Mu sebeleza.\n" +
                "\n" +
                "MAKUTELO:\n" +
                "Mautu, mamela, Zamaya hande,\n" +
                "Ni ta sebeleza Jesu A nosi. \n" +
                "\n" +
                "2.Lizebe za ka, utwa, Lizazi kaufela, \n" +
                "Ka likezo za musa, Z’o kona ku eza.\n" +
                "\n" +
                "3.Meto a ka a lisa, Mazoho, mautu,\n" +
                "Ku a sabisa bubi, Ka ‘baka la Jesu.");

        data.add(
                "1.Lwa taba ka lilato, La lu wabelisa;\n" +
                        "Li lu fa mukekecima, Kwa batu ba bañwi.\n" +
                        "\n" +
                        "MAKUTELO:\n" +
                        "Mulimu U lata banana, Kabe lu ba sina Yena;\n" +
                        "Lwa taba ka lilato, La lu wabelisa;\n" +
                        "Li lu fa makekecima, Kwa batu ba bañwi.\n" +
                        "\n" +
                        "2.Fa fasi ki manyando, Matuku ni lifu;\n" +
                        "Ka ku taba lu ta lika, Ku kwenula mutu.\n" +
                        "\n" +
                        "3.Ha bupilo bu fela, Mi lu se lu bizwa;\n" +
                        "Lu ta y’o opela pina, Ya musa wa Jesu. ");

        data.add( "1.Bahali ba Jesu! A mu ye kwa ndwa,\n" +
                "Ni sifapano sa Jesu fa pili;\n" +
                "Kelesite Jesu, wa etelela,\n" +
                "Zwela pili mwa ndwa, Bona Ndembela. \n" +
                "\n" +
                "MAKUTELO:\n" +
                "Bahali ba Jesu, A mu ye kwa ndwa,\n" +
                "Ni sifapano sa Jesu fa pili.\n" +
                "\n" +
                "2.Ha lu bat’o koma, Sila sa saba,\n" +
                "Ki fo he bahali, A lu hape ndwa!\n" +
                "Mukosi wa lila, Mabita ‘njanja. \n" +
                "Banna, mu tiise Pina ya mina. \n" +
                "\n" +
                "3.Ba ya inge mwa ndwa, Batu ba Jesu,\n" +
                "Banna lu nga nzila Ya balumeli;\n" +
                "Lu sa kauhani, lu nto iliñwi,\n" +
                "Sepo ni tumelo Ni mwa lilato.\n" +
                "\n" +
                "4.Mabona a ile, Ee ni mibuso.\n" +
                "Keleke ya Jesu i sa siyezi;\n" +
                "Libita ha li  na ku ipwenkisa.\n" +
                "Sepiso ya Jesu, Ha i fokoli.\n" +
                "\n" +
                "5.A mu tahe batu! Lu t’o kopana,\n" +
                "Lu bine hamoho Pina ya tulo;\n" +
                "Kanya ni likute Li be ku Jesu,\n" +
                "Ki pina ya batu ni mañeloi.");

        data.add(
                "1.Moyo, tokomela! Lila ki bolule;\n" +
                        "Limpi za sibi za ata, Li t’o ku kelusa.\n" +
                        "\t\n" +
                        "2.Lwana lu lapele! Si lobazi tebe;\n" +
                        "U ipe maata kamita, Jesu U ta tusa.\n" +
                        "\n" +
                        "3.Si li u komile, Si lobazi tebe;\n" +
                        "Ku sa na ni musebezi, Mane u y’o fenya");

        data.add(
                "1.Zuha, moyo wa ka, zuha!\n" +
                        "U sunde ka maata;\n" +
                        "Siyano ki tundameno\n" +
                        "Ku bata bupilo.\n" +
                        "\n" +
                        "2.Ki linzwi la Mupulusi,\n" +
                        "Li nze li ku biza;\n" +
                        "Ki Yena Ya fa mupuzo\n" +
                        "Ku wena ya tokwa.\n" +
                        "\n" +
                        "3.Lipaki zeñata-ñata,\n" +
                        "Za ku talimela;\n" +
                        "U siye nzila ya kale.\n" +
                        "Mi u zwele pili.\n" +
                        "\n" +
                        "4.Mupulusi ya lateha\n" +
                        "Lu kala siyano;\n" +
                        "Mi ha lu se lu komile\n" +
                        "Lu ta lula kapo.");

        data.add( "l. Na ta kwa sifapano, Ni nze ni li sibofu; \n" +
                "   Tutu ki matakala, Ha ni luwa bupilo. \n" +
                "\n" +
                "MAKALELO:\n" +
                "   Na ku sepa, Mulena, Ngunyana Ye tabilwe; \n" +
                "   Na kubama fa fasi, Ni pilise Mulena.\n" +
                " \n" +
                "2. Ni ku lilezi kale, Sibi si ni busize; \n" +
                "   Mulena U li ku 'na, \"Ni ta takula libi.\" \n" +
                "\n" +
                "3. Ni ku fa lika za ka, Nako ni za lifasi; \n" +
                "   Bupilo ni mubili, Ki za Jesu Kamita. \n" +
                "\n" +
                "4. Ni sepa lisepiso, Ni se ni utwa mali; \n" +
                "   Ni wela mwa maluli, Ni takiswa ni Jesu. \n" +
                "\n" +
                "5. Jesu Wa ta! na taba! Ni se ni petehile; \n" +
                "   Ni se ni folisizwe, Kanya, Kanya Ku Jesu.");



    }

}
