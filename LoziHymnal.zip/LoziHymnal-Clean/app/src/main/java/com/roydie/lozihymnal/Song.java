package com.roydie.lozihymnal;

/**
 * Created by rsimasiku on 11/9/2015.
 */
public class Song {

    private String title;
    private int img;
    private Team description;

    public Song(String title, int img)

    {
        this.title = title;
        this.img = img;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public Team getDescription() {
        return description;
    }

    public void setDescription(Team description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return title;
    }

}